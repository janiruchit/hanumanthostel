## Packages
qrcode.react | Generate QR codes for UPI payments
date-fns | Date formatting for rent records and menu days

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
